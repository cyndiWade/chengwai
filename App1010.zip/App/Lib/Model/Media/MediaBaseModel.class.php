<?php 

/**
 * 后台管理模型类
 */

class MediaBaseModel extends AppBaseModel {
	

	public function __construct() {
		parent::__construct();
		
	}
	
	
	
	
}
?>