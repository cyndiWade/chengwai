<?php

//标签类别表
class CategoryTagsModel extends AdminBaseModel {
	
	
}

?>
