<?php

/**
 * 组与节点模型表
 */

class GroupNodeModel extends AdminBaseModel {
	

	
}

?>
