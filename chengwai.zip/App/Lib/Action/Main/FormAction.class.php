<?php
/**
 * 
 */
class FormAction extends MainBaseAction {
    

	public function form_elements()    {

		$this->display();
	}

	
	public function form_validation () {
		$this->display();
	}
	
    
}