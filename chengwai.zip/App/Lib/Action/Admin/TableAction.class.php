<?php
/**
 * 登陆控制器
 * @author Administrator
 *
 */
class TableAction extends AdminBaseAction {
    
	
	public function index() {
	
	}
    
	
	public function aaa() {

	}
	
}