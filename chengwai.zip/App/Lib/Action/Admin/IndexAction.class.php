<?php
/**
 * 首页
 * @author Administrator
 *
 */
class IndexAction extends AdminBaseAction {
    
	
	public function index() {

	}
    
	

	
}