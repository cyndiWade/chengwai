<?php 

/**
 * 后台管理模型类
 */

class AdvertBaseModel extends AppBaseModel {
	
	

	public function __construct() {
		parent::__construct();
		
	}
	
	
	
	
	
	
	
}
?>