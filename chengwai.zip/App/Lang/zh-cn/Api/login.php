<?php 
/**
 * 独立语言包
 */
return array(
	
);


?>