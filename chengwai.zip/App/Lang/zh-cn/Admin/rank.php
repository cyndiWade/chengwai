<?php 
/**
 * 模块语言包
 */
return array(
	//会员
	'member'=> array(
		'area' => '所属区域'	,
		'card_number' => '会员卡号',
		'source'=> '会员来源',
		'name'=> '会员姓名',
		'sex'=> '会员性别'
			
	) ,
	
	//股东
	'shareholder' => array(
		'area' => '投资区域',
		'card_number' => '股东会员卡',
		'source'=> '股东来源',
		'name'=> '股东姓名',
		'sex'=> '股东性别'
			
	),
);


?>