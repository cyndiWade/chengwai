详细的参数以及说明文档都在

external-dragging_demo.html  文件中